
import React from 'react';
import { List } from 'material-ui/List';
import {
    Card,CardText
} from 'reactstrap';

const styles = {
    width: 320,
    height: 460,
    margin: '25px',
    display: 'block',
    float: 'left',
    'background-color': '#fff',
    'box-radius': '15px',
};

class GameCard extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
        }
    }

    render() {
        return (
            <Card style={styles} className="cardLayput">
                <CardText>
                    <List className="listStyle">
                        {this.props.gameInfo.links.mission_patch ? <img src={this.props.gameInfo.links.mission_patch}  alt="image link" height="100" width="100" className="imageStyle" /> : <div className="imageNotAvailable">image not available</div>}
                        <div className="listLine">
                            <span className="missionName">{this.props.gameInfo.mission_name + " # " + this.props.gameInfo.flight_number}</span>
                        </div>
                        <div className="listLine">
                            <span className="launchYear">Mission Id:   {this.props.gameInfo.mission_id.length ? this.props.gameInfo.mission_id : this.props.gameInfo.launch_site.site_id}</span>
                        </div>
                        <div className="listLine">
                            <span className="launchYear">Launch year: {this.props.gameInfo.launch_year}</span>
                        </div>
                        <div className="listLine">
                            <span className="launchYear">Launch success: {this.props.gameInfo.launch_success ? "true" : "false"}</span>
                        </div>
                        <div className="listLine">
                            <span className="launchYear">Successfull landing: {this.props.gameInfo.launch_success ? "true" : "false"}</span>
                        </div>
                    </List>
                </CardText>
            </Card>
        );
    }
}

export default GameCard;