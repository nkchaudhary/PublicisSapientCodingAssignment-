import React from 'react';
import axios from 'axios';
import GameCard from './gameCard.js';
import { Container, Row, Col } from 'reactstrap';
import Loader from "./Loader";
import YearsLaunch from "./yearsLaunch";
import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid';

class GameArea extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            gamesList: [],
            masterList: [],
            open: false,
            open2: false,
            launch_year: [],
            genres: [],
            filterData: {
            },
            mission_name: [],
            launch_success: [],
            sort: false,
        }
    }

    getFilterOptions = (list) => {
        let launch_year = [], genres = [], mission_name = [], launch_success = [];
        list.map((game) => {
            let mission_name = game.mission_name.split(',');
            mission_name.map(gameGenre => {
                if (gameGenre && genres.indexOf(gameGenre) === -1) {
                    genres.push(gameGenre);
                }
            });
            if (launch_year.indexOf(game.launch_year) === -1) {
                launch_year.push(game.launch_year);
            }
            if (mission_name.indexOf(game.mission_name) === -1) {
                mission_name.push(game.mission_name);
            }
            if (launch_success.indexOf(game.launch_success) === -1) {
                launch_success.push(game.launch_success);
            }
        });
        this.options = { launch_year, genres, mission_name, launch_success };
        this.props.onDropDownOptions(this.options);
    }

    getFilterData = (list) => {
        if (this.props.filterData) {
            console.log(this.props.filterData)
        }
        return list;
    }

    componentDidMount() {
        axios.get('https://api.spacexdata.com/v3/launches')
            .then(response => {
                let list = response.data;
                list.shift();
                this.getFilterOptions(list);
                this.setState({
                    gamesList: list,
                    masterList: list
                });
            });
    }

    componentDidUpdate(previousprops) {
        let gameList = this.state.masterList;
        let launch_year = this.props.filterData.launch_year;
        let oldLaunchYear = previousprops.filterData.launch_year;
        let mission_name = this.props.filterData.mission_name;
        let gameName = this.props.filterData.search;
        let scoreSort = this.props.filterData.score;
        let newList = gameList;
        if ((launch_year && oldLaunchYear !== launch_year) || (mission_name && previousprops.filterData.mission_name !== mission_name) || (gameName && gameName !== previousprops.filterData.search) || (scoreSort && scoreSort !== previousprops.filterData.score)) {
            if (launch_year && launch_year !== 'None')
                newList = gameList.filter(game => game.launch_year === launch_year);
            if (mission_name && mission_name !== 'None')
                newList = newList.filter(game => game.mission_name.indexOf(mission_name) > -1);
            if (gameName && gameName.trim()) {
                newList = newList.filter(game => {
                    if (gameName === game.mission_name || game.mission_name.indexOf(mission_name) > -1) {
                        return true;
                    }
                });
            }
            if (scoreSort) {
                if (scoreSort === 'asc') {
                    newList = newList.sort((a, b) => {
                        return a.score - b.score;
                    })
                } else {
                    newList = newList.sort((a, b) => {
                        return b.score - a.score;
                    })
                }
            }
            this.setState({
                gamesList: newList
            });
        }
    }
    onDropDownOptions = (options) => {
        options.launch_year.unshift('None');
        options.genres.unshift('None');
        this.setState({
            launch_year: options.launch_year,
            genres: options.genres,
            mission_name: options.mission_name,
            launch_success: options.launch_success
        });
    }

    handleClick = (event) => {
        event.preventDefault();
        this.setState({
            open: true,
            anchorEl: event.currentTarget,
        });
    };

    handleClickGenre = (event) => {
        event.preventDefault();
        this.setState({
            open2: true,
            anchorEl2: event.currentTarget,
        });
    };

    handleRequestClose = () => {
        this.setState({
            open: false,
            open2: false
        });
    };

    search = (searchText) => {
        this.filterData({ 'search': searchText });
    };

    filterData = (category) => {
        let filterData = this.state.filterData;
        this.setState({
            filterData: Object.assign({}, filterData, category),
            open: false,
            open2: false
        });
    }

    resetLaunchYear = () => {
        this.filterData({ launch_year: 'None' });
    }

    resetGenre = () => {
        this.filterData({ genre: 'None' });
    }

    sortScore = (sort) => {
        this.filterData({ 'score': sort });
        let sortValue = !this.state.sort;
        this.setState({
            sort: sortValue
        })
    }
    render() {
        return (
            <Container>
                <Grid container spacing={24}>
                    <Grid item xs={2} style={{"background":"#fff"}}>
                        <Paper className={"xs=2"}>
                            <span className="launchYear"><p className="heading">Launch year</p> {this.state.gamesList.length ? <span>  <YearsLaunch gameInfo={Array.from(new Set(this.state.gamesList.map((item) => item.launch_year)))} /></span> : <span> No records found </span>}</span>
                        </Paper>
                        
                        {/* <Paper>
                            <span className="launchYear">Launch success  {this.state.gamesList.launch_successF ? <Button variant="outlined" color="primary" className="btnstyle">True</Button> : <Button variant="outlined" color="primary" className="btnstyle">False</Button>}</span>
                        </Paper>
                        <Paper>
                            <span className="launchYear">Successfull landing {this.state.gamesList.launch_success ? "true" : "false"}</span>
                        </Paper> */}
                    </Grid>
                    <Grid item xs={10}>
                        <Paper className={"xs=10"}>
                            <Col lg="9"> {this.state.gamesList.length ? <span> {this.state.gamesList.map((game) => <GameCard gameInfo={game} />)} </span> : <span>
                                <div>
                                    <Loader />
                                </div> </span>}</Col>
                        </Paper>
                    </Grid>
                </Grid>
                <Row>
                    <span className="dev"> Developed by Narendra Kumar</span>
                </Row>
            </Container>
        );
    }
}

export default GameArea;