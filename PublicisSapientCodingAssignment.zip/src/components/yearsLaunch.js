
import React from 'react';
import Button from '@material-ui/core/Button';
import Chip from 'material-ui/Chip';

class yearsLaunch extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            open: true,
            launch_year: [],
            genres: [],
            filterData: {
            },
            mission_name: [],
            launch_success: [],
            sort: false
        };
    }

    onDropDownOptions = (options) => {
        options.launch_year.unshift('None');
        options.genres.unshift('None');
        this.setState({
            launch_year: options.launch_year,
            genres: options.genres,
            mission_name: options.mission_name,
            launch_success: options.launch_success
        });
    }

    handleClick = (event) => {
        event.preventDefault();
        this.setState({
            open: true,
            anchorEl: event.currentTarget,
        });
    };

    handleRequestClose = () => {
        this.setState({
            open: true,
        });
    };

    filterData = (category) => {
        let filterData = this.props.gameInfo;
        this.setState({
            filterData: Object.assign({}, filterData, category),
            open: true,
        });
    }

    resetLaunchYear = () => {
        this.filterData({ launch_year: 'None' });
    }

    render() {

        return (
            <div>
                {this.props.gameInfo.length ? <span> {this.props.gameInfo.map((launch_year) => <Button variant="outlined" color="primary" className="btnstyle" onClick={this.filterData.bind(this, { launch_year })}>{launch_year}</Button>)} </span> : <span>No data</span>}
                {(this.state.filterData.launch_year && this.state.filterData.launch_year !== 'None') ?
                    <Chip style={{ margin: '15px' }} onRequestDelete={this.resetLaunchYear}>
                        {this.state.filterData.launch_year}
                    </Chip> : <div></div>}
                    {/* <GameArea onDropDownOptions1={this.onDropDownOptions} filterData1={this.state.filterData} />     */}
            </div>
        );
    }
}

export default yearsLaunch;