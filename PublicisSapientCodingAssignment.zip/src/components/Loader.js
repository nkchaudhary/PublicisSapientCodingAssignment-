import React from "react";
import "./Loader.css";

const Loader = () => {
  return (
    <React.Fragment>
      <div className="nav-loader"></div>
    </React.Fragment>
  );
};

export default Loader;
