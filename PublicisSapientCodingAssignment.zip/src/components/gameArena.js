import React, { Component } from 'react';
import AppBar from 'material-ui/AppBar';
import GameArea from './gameArea.js';
import FlatButton from 'material-ui/FlatButton';
import Popover from 'material-ui/Popover';
import Menu from 'material-ui/Menu';
import MenuItem from 'material-ui/MenuItem';
import Chip from 'material-ui/Chip';
import Person from 'material-ui/svg-icons/social/person';

const style = {
	'background-color': '#3a3a3a',
	'text-align': 'left'
};

const buttonStyles = {
	margin: '15px'
}

class GameArena extends Component {

	constructor(props) {
		super(props);
		this.state = {
			open: false,
			open2: false,
			launch_year: [],
			genres: [],
			filterData: {
			},
			mission_name: [],
			launch_success: [],
			sort: false
		};
	}

	onDropDownOptions = (options) => {
		options.launch_year.unshift('None');
		options.genres.unshift('None');
		this.setState({
			launch_year: options.launch_year,
			genres: options.genres,
			mission_name: options.mission_name,
			launch_success: options.launch_success
		});
	}

	handleClick = (event) => {
		event.preventDefault();
		this.setState({
			open: true,
			anchorEl: event.currentTarget,
		});
	};
	
	handleRequestClose = () => {
		this.setState({
			open: false,
			open2: false
		});
	};

	filterData = (category) => {
		let filterData = this.state.filterData;
		this.setState({
			filterData: Object.assign({}, filterData, category),
			open: false,
			open2: false
		});
	}

	resetLaunchYear = () => {
		this.filterData({ launch_year: 'None' });
	}

	render() {
		return (
			<div>
				<AppBar
					style={style}
					title='SpaceX Launch Programs'>
					<FlatButton
						style={buttonStyles}
						backgroundColor="white"
						hoverColor="white"
						onClick={this.handleClick}
						label="Filter"
					/>
					<Popover
						open={this.state.open}
						anchorEl={this.state.anchorEl}
						anchorOrigin={{ horizontal: 'left', vertical: 'bottom' }}
						targetOrigin={{ horizontal: 'left', vertical: 'top' }}
						onRequestClose={this.handleRequestClose}
					>
						<Menu>
							{this.state.launch_year.map(launch_year => <MenuItem primaryText={launch_year} onClick={this.filterData.bind(this, { launch_year })} />)}
						</Menu>
					</Popover>
					{(this.state.filterData.launch_year && this.state.filterData.launch_year !== 'None') ?
						<Chip style={{ margin: '15px' }} onRequestDelete={this.resetLaunchYear}>
							{this.state.filterData.launch_year}
						</Chip> : <div></div>}
					<a target="_blank" href="https://www.linkedin.com/in/narendra-kumar-chaudhary-60493568/" ><Person style={{ margin: '20px', fill: 'white' }} /></a>
				</AppBar>
				<GameArea onDropDownOptions={this.onDropDownOptions} filterData={this.state.filterData} />
			</div>
		);
	}
}

export default GameArena;